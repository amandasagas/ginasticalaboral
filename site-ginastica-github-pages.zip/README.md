# Site Ginástica Laboral
Arquivos prontos para **GitHub Pages**.

## Como publicar
1. Crie um repositório **público** no GitHub (ex.: `ginastica-laboral`).
2. Envie **estes três arquivos** para a raiz do repositório:
   - `index.html`
   - `.nojekyll`
   - `README.md` (opcional)
3. Vá em **Settings → Pages** e selecione:
   - **Branch:** `main`
   - **Folder:** `/ (root)`
   - **Save`
4. O link ficará: `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`
